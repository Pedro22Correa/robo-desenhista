/*
 * Robô Desenhista — ZOOM
 * Feito por Pedro Lima, Orientador Educacional (ZOOM Education for Life).
 * O robô desenha na folha com a caneta que o aluno escolher. Simulador, execução dos blocos e interface.
 * Escala: 1 quadrado da folha = 1 cm.
 */
(function () {
  'use strict';
  var A = window.ROBO_ARQUIVOS; // imagens embutidas (robôs, controles, logo)

  // Folha de desenho: de x = −16 a 18 cm e de y = −7 a 17 cm (o robô anda em cm, com o centro da folha em 0,0)
  var PAP = { x0: -16, x1: 18, y0: -7, y1: 17 }, PPC = 24;
  var MAT = { w: (PAP.x1 - PAP.x0) * PPC, h: (PAP.y1 - PAP.y0) * PPC, ax: -PAP.x0 * PPC, ay: PAP.y1 * PPC, ppcX: PPC, ppcY: PPC };
  var CEL = 10, PASSO = 10;
  var VEL_LINEAR = 10, VEL_GIRO = 90, BITOLA = 8, TAM_ROBO = 8.6;
  // cada robô: id, nome, imagem, tamanho na folha (cm), qual lista de dicas e quais fases mostrar (ordem do Scratch)
  var ROBOS = [
    { id: 'vincibot', nome: 'VinciBot', img: A.robo, tam: 8.6, dicas: 'vincibot', fases: [1, 2, 3, 5] },
    { id: 'matata', nome: 'Matata', img: A.roboMatata, tam: 8.6, dicas: 'facil', fases: [1, 4, 2] },
    { id: 'nous', nome: 'Nous IA', img: A.roboNous, tam: 10, dicas: 'scratch', fases: [1, 2, 3, 4, 5] },
    { id: 'tale', nome: 'Tale', img: A.roboTale, tam: 9, dicas: 'facil', fases: [1, 4, 2] }
  ];
  // fases do desafio (as medidas e os giros vêm do Scratch): lados em cm, giro em graus, limite de setas
  var FASES = [
    { id: 1, nome: 'Quadrado', ic: '⬜', lados: [10, 10, 10, 10], ang: 90, lim: 8 },
    { id: 2, nome: 'Triângulo', ic: '🔺', lados: [10, 10, 10], ang: 120, lim: 6 },
    { id: 3, nome: 'Pentágono', ic: '⬠', lados: [10, 10, 10, 10, 10], ang: 72, lim: 10 },
    { id: 4, nome: 'Retângulo', ic: '▭', lados: [20, 10, 20, 10], ang: 90, lim: 10 },
    { id: 5, nome: 'Estrela', ic: '⭐', lados: [10, 10, 10, 10, 10], ang: 144, lim: 10 }
  ];
  var DICAS = {
    facil: ['O quadrado tem 4 lados iguais: anda, gira, anda, gira... (8 setas)', 'O triângulo tem 3 lados: anda e gira 3 vezes (6 setas)', 'O pentágono tem 5 lados: anda e gira 5 vezes!',
      'Use ↑↑ (20 cm) nos lados compridos e ↑ (10 cm) nos curtos. Gire sempre para o mesmo lado!', 'A estrela tem 5 pontas: anda e gira 5 vezes!'],
    vincibot: ['Quadrado: quantos lados? Cada lado mede 10 cm. Giro = 360 ÷ 4.', 'Triângulo: 3 lados de 10 cm. Giro = 360 ÷ 3.', 'Pentágono: 5 lados de 10 cm. Giro = 360 ÷ 5.',
      'Retângulo: lados de 20 cm e 10 cm, giros de 90°.', 'Estrela: 5 linhas de 10 cm. O giro é de 144°!'],
    scratch: ['4 lados iguais de 10 cm. Giro: 360 ÷ 4 = 90°. Use repita 4!', '3 lados de 10 cm. Giro: 360 ÷ 3 = 120°.', '5 lados de 10 cm. Giro: 360 ÷ 5 = 72°.',
      'Lados de 20 cm e 10 cm, alternando, com giros de 90°. Repita 2 vezes!', '5 linhas de 10 cm e giros de 144°. Repita 5 vezes!']
  };
  var CANETAS = [
    { id: 'blue', nome: 'azul', cor: '#2563d4' }, { id: 'green', nome: 'verde', cor: '#1f9d49' }, { id: 'yellow', nome: 'amarela', cor: '#f0b400' },
    { id: 'red', nome: 'vermelha', cor: '#e0302b' }, { id: 'black', nome: 'preta', cor: '#25272b' }
  ];
  var INI_LIVRE = { x: 0, y: 0, dir: 0 }, INI_FASE = { x: -4, y: 9, dir: 90 };   // na fase o robô sai do canto de cima, olhando para a direita
  var NOMES_COR = { white: 'branco', black: 'preto', grey: 'cinza', red: 'vermelho', yellow: 'amarelo', green: 'verde', blue: 'azul', purple: 'roxo', unknown: '—' };

  var LS = 'robodesenhista.';
  function carregar(k, padrao) { try { var v = localStorage.getItem(LS + k); return v === null ? padrao : JSON.parse(v); } catch (e) { return padrao; } }
  function salvar(k, v) { try { localStorage.setItem(LS + k, JSON.stringify(v)); } catch (e) { /* sem armazenamento */ } }

  var cfg = {
    aberto: carregar('aberto', window.innerWidth >= 760 && window.innerHeight >= 520), largura: carregar('largura', 480),
    turbo: carregar('turbo', 1), som: carregar('som', true), robo: carregar('robo', 'vincibot'), fase: carregar('fase', 0), caneta: carregar('caneta', '')
  };

  var robo = { x: 0, y: 0, dir: 0, led: null, balanco: 0 };
  var tela = { px: new Float32Array(128), rolagem: null };
  var som = { tempo: 60 };
  var movimento = null, tracos = [], traco = null;
  var jogo = { ok: false, acerto: null };
  var exec = { rodando: false, ficha: null, pilhas: [], crono: 0, esperas: [] };
  var ui = {}, ws = null;
  var imgRobo = new Image();

  /* ---------- Utilidades ---------- */
  function limpar(v) { return Math.abs(v - Math.round(v)) < 1e-6 ? Math.round(v) : v; }
  function numero(v, padrao) { var n = parseFloat(v); return isFinite(n) ? n : (padrao || 0); }
  function nomeDir(d) { d = ((d % 360) + 360) % 360; return ['Norte', 'Nordeste', 'Leste', 'Sudeste', 'Sul', 'Sudoeste', 'Oeste', 'Noroeste'][Math.round(d / 45) % 8]; }
  function robocfg() { return ROBOS.filter(function (r) { return r.id === cfg.robo; })[0] || ROBOS[0]; }
  function faseAtual() { return cfg.fase ? FASES[cfg.fase - 1] : null; }
  function canetaAtual() { return CANETAS.filter(function (c) { return c.id === cfg.caneta; })[0] || null; }

  // nesta folha não há cores nem obstáculos: os sensores enxergam papel branco e nada à frente
  function classificarCor() { return 'white'; }
  function corSob() { return [255, 255, 255]; }
  function distanciaFrente() { return 400; }

  /* ---------- Física ---------- */
  function limitar() {
    var m = 0.5, bateu = false;
    if (robo.x < PAP.x0 + m) { robo.x = PAP.x0 + m; bateu = true; } if (robo.x > PAP.x1 - m) { robo.x = PAP.x1 - m; bateu = true; }
    if (robo.y < PAP.y0 + m) { robo.y = PAP.y0 + m; bateu = true; } if (robo.y > PAP.y1 - m) { robo.y = PAP.y1 - m; bateu = true; }
    return bateu;
  }
  function batida(t) { aviso(t); nota(110, 0.16, 'sawtooth'); }
  function terminar(m) {
    if (movimento === m) movimento = null;
    robo.x = limpar(robo.x); robo.y = limpar(robo.y); robo.dir = limpar(robo.dir);
    if (m && m.fim) { var f = m.fim; m.fim = null; f(); }
  }
  function iniciar(m) {
    if (movimento) { var ant = movimento; movimento = null; if (ant.fim) { var f = ant.fim; ant.fim = null; f(); } if (ant.tipo === 'rodas' && m.tipo !== 'rodas') servoParaTudo(); }
    movimento = m;
    return new Promise(function (ok) { m.fim = ok; if ((m.tipo === 'linear' || m.tipo === 'giro') && Math.abs(m.resta) < 1e-9) terminar(m); });
  }
  function pararMovimento() { if (movimento) { var m = movimento; movimento = null; robo.balanco = 0; if (m.fim) { var f = m.fim; m.fim = null; f(); } if (m.tipo === 'rodas') servoParaTudo(); } }

  /* ---------- Caneta: o que o robô desenha ---------- */
  function riscar(ax, ay) {
    var c = canetaAtual(); if (!c) { traco = null; return; }
    if (!traco || traco.id !== c.id) { traco = { id: c.id, cor: c.cor, pts: [[ax, ay]] }; tracos.push(traco); }
    var u = traco.pts[traco.pts.length - 1];
    if (Math.abs(u[0] - robo.x) + Math.abs(u[1] - robo.y) > 0.12) { traco.pts.push([robo.x, robo.y]); if (traco.pts.length > 6000) traco.pts.shift(); }
  }
  function apagarDesenho() { tracos = []; traco = null; jogo.ok = false; jogo.acerto = null; if (ui.placar) ui.placar.textContent = ''; }
  function passo(dt) {
    dt *= cfg.turbo;
    if (exec.rodando) exec.crono += dt;
    for (var i = exec.esperas.length - 1; i >= 0; i--) { var e = exec.esperas[i]; e.resta -= dt; if (e.resta <= 0) { exec.esperas.splice(i, 1); e.ok(); } }
    var m = movimento;
    if (m) {
      var rad = robo.dir * Math.PI / 180, ax = robo.x, ay = robo.y;
      if (m.tipo === 'linear') {
        var d = Math.min(Math.abs(m.resta), m.vel * dt), s = m.resta < 0 ? -1 : 1;
        robo.x += Math.sin(rad) * d * s; robo.y += Math.cos(rad) * d * s; m.resta -= d * s;
        if (limitar()) { m.resta = 0; batida('O robô chegou na borda da folha.'); }
        if (Math.abs(m.resta) < 1e-9) terminar(m);
      } else if (m.tipo === 'giro') {
        var g = Math.min(Math.abs(m.resta), m.vel * dt), sg = m.resta < 0 ? -1 : 1;
        robo.dir += g * sg; m.resta -= g * sg;
        if (Math.abs(m.resta) < 1e-9) { robo.dir = ((robo.dir % 360) + 360) % 360; terminar(m); }
      } else if (m.tipo === 'rodas') {
        var vm = {}, ativo = false;
        Object.keys(servos).forEach(function (k) { vm[k] = servoVel(k, dt); if (servoAtivo(servos[k])) ativo = true; });
        var vle = vm[1] || 0, vri = -(vm[2] || 0), v2 = (vle + vri) / 2, w2 = (vle - vri) / BITOLA_NOUS;
        robo.dir += w2 * dt * 180 / Math.PI; rad = robo.dir * Math.PI / 180;
        robo.x += Math.sin(rad) * v2 * dt; robo.y += Math.cos(rad) * v2 * dt;
        limitar();
        if (!ativo && movimento === m) { movimento = null; if (m.fim) { var f2 = m.fim; m.fim = null; f2(); } }
      } else if (m.tipo === 'continuo') {
        var v = (m.vl + m.vr) / 2, w = (m.vl - m.vr) / BITOLA;
        robo.dir += w * dt * 180 / Math.PI; rad = robo.dir * Math.PI / 180;
        robo.x += Math.sin(rad) * v * dt; robo.y += Math.cos(rad) * v * dt;
        limitar();
      }
      if (robo.x !== ax || robo.y !== ay) riscar(ax, ay);
    }
    passoTela(dt); dispararEventos();
  }

  /* ---------- Som ---------- */
  var ac = null, master = null, vozes = [];
  function audio() {
    if (!cfg.som) return null;
    if (!ac) { var C = window.AudioContext || window.webkitAudioContext; if (!C) return null; try { ac = new C(); } catch (e) { return null; } master = ac.createGain(); master.gain.value = 0.4; master.connect(ac.destination); }
    if (ac.state === 'suspended') { try { ac.resume(); } catch (e) { /* aguarda gesto */ } }
    return ac;
  }
  function nota(freq, dur, tipo, atraso) {
    var a = audio(); if (!a) return;
    var o = a.createOscillator(), g = a.createGain(), t = a.currentTime + (atraso || 0);
    o.type = tipo || 'triangle'; o.frequency.setValueAtTime(freq, t);
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.9, t + 0.015);
    g.gain.setValueAtTime(0.9, t + Math.max(0.02, dur - 0.05)); g.gain.linearRampToValueAtTime(0.0001, t + dur);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + dur + 0.02); vozes.push(o);
    o.onended = function () { var i = vozes.indexOf(o); if (i >= 0) vozes.splice(i, 1); };
  }
  function freqMidi(n) { return n > 127 ? n : 440 * Math.pow(2, (n - 69) / 12); }
  function silenciar() {
    vozes.slice().forEach(function (v) { try { v.stop(); } catch (e) { /* já parou */ } }); vozes = [];
    try { if (window.speechSynthesis) window.speechSynthesis.cancel(); } catch (e) { /* sem voz */ }
  }
  function tocarVitoria() { [72, 76, 79, 84].forEach(function (n, i) { nota(freqMidi(n), 0.16, 'triangle', i * 0.13); }); }

  /* ---------- Telinha do rosto (16 x 8) ---------- */
  function figura(l) { var a = new Float32Array(128); for (var y = 0; y < 8; y++) for (var x = 0; x < 16; x++) a[y * 16 + x] = l[y][x] === '#' ? 1 : 0; return a; }
  var IMAGENS = {
    olhos: figura(['................', '................', '...###....###...', '..#####..#####..', '..#...#..#...#..', '................', '................', '................']),
    feliz: figura(['................', '...##......##...', '..####....####..', '................', '...#........#...', '....#......#....', '.....######.....', '................']),
    triste: figura(['................', '...##......##...', '...##......##...', '................', '.....######.....', '....#......#....', '...#........#...', '................']),
    surpreso: figura(['...##......##...', '..#..#....#..#..', '..#..#....#..#..', '...##......##...', '.......##.......', '......#..#......', '.......##.......', '................']),
    coracao: figura(['................', '....##...##.....', '...####.####....', '...#########....', '....#######.....', '.....#####......', '......###.......', '.......#........']),
    certo: figura(['................', '............##..', '...........##...', '..........##....', '...##....##.....', '....##..##......', '.....####.......', '......##........']),
    errado: figura(['................', '....##....##....', '.....##..##.....', '......####......', '......####......', '.....##..##.....', '....##....##....', '................']),
    seta: figura(['.......##.......', '......####......', '.....######.....', '....########....', '.......##.......', '.......##.......', '.......##.......', '.......##.......'])
  };
  function mostrarFigura(a) { tela.rolagem = null; tela.px.set(a); }
  function mostrarTexto(texto) {
    var c = document.createElement('canvas'); c.height = 8; c.width = 16;
    var g = c.getContext('2d'); g.font = 'bold 9px monospace';
    var larg = Math.max(1, Math.ceil(g.measureText(texto).width)) + 1;
    c.width = larg; g = c.getContext('2d', { willReadFrequently: true }); g.font = 'bold 9px monospace'; g.textBaseline = 'top'; g.fillStyle = '#fff';
    g.fillText(texto, 0, -1);
    var d = g.getImageData(0, 0, larg, 8).data, cols = [];
    for (var x = 0; x < larg; x++) { var col = []; for (var y = 0; y < 8; y++) col.push(d[(y * larg + x) * 4 + 3] > 90 ? 1 : 0); cols.push(col); }
    if (larg <= 16) { tela.rolagem = null; tela.px.fill(0); cols.forEach(function (cl, x2) { for (var y2 = 0; y2 < 8; y2++) tela.px[y2 * 16 + x2] = cl[y2]; }); }
    else tela.rolagem = { cols: cols, pos: -16 };
  }
  function passoTela(dt) {
    var r = tela.rolagem; if (!r) return;
    r.pos += dt * 14; var base = Math.floor(r.pos);
    for (var x = 0; x < 16; x++) { var col = r.cols[base + x]; for (var y = 0; y < 8; y++) tela.px[y * 16 + x] = col ? col[y] : 0; }
    if (base > r.cols.length) tela.rolagem = null;
  }

  /* ---------- Comandos que os blocos chamam ---------- */
  var PARAR = { parar: true };
  function vivo(ficha) { if (!ficha || ficha.cancelada) throw PARAR; }
  function esperarSeg(seg) { return new Promise(function (ok) { if (!(seg > 0)) { ok(); return; } exec.esperas.push({ resta: seg, ok: ok }); }); }
  var proximoQuadro = [];
  // Servomotores do perfil Nous: o motor 1 é a roda esquerda e o motor 2 a roda direita.
  // As rodas ficam montadas invertidas: potência positiva em 1 anda para frente, em 2 anda para trás
  // (por isso 50,50 faz o robô girar no lugar, e para andar reto usa-se 50,-50).
  var CIRC_RODA = Math.PI * 6.8, BITOLA_NOUS = 13.7, ANG_PADRAO = 50; // roda de 68 mm e distância entre rodas de 137 mm (padrão do Nous)
  var RODA_NOUS = 68, EIXOS_NOUS = 137, roda = { d: 68, b: 137, defD: false, defB: false, avisouD: false, avisouB: false }; // mm. O que vale no robô de verdade é o que o programa configura
  var servos = {};
  function lista(t) { return String(t).split(',').map(function (x) { return Number(x.trim()); }).filter(function (x) { return isFinite(x); }); }
  function servo(i) { return servos[i] || (servos[i] = { ang: 0, vel: 0, alvo: null, vAlvo: 0, tempo: 0, esp: [] }); }
  function servoAtivo(s) { return s.vel !== 0 || s.alvo !== null || s.tempo > 0; }
  function servoLiberar(s) { var f = s.esp; s.esp = []; f.forEach(function (ok) { ok(); }); }
  function servoParaTudo() { Object.keys(servos).forEach(function (k) { var s = servos[k]; s.vel = 0; s.alvo = null; s.tempo = 0; servoLiberar(s); }); }
  function servoAcordar() { if (!movimento || movimento.tipo !== 'rodas') iniciar({ tipo: 'rodas' }); }
  function degPorSeg(pct) { return Math.abs(pct) / 100 * VEL_LINEAR / CIRC_RODA * 360; }
  function servoEsperar(ids) {
    return Promise.all(ids.map(function (i) { var s = servo(i); return servoAtivo(s) ? new Promise(function (ok) { s.esp.push(ok); }) : undefined; }));
  }
  // cm/s que o motor i empurra no sentido positivo dele, neste quadro
  function servoVel(i, dt) {
    var s = servo(i), cm = 0, d, passoAng;
    if (s.alvo !== null) {
      d = s.alvo - s.ang; passoAng = Math.min(Math.abs(d), s.vAlvo * dt) * (d < 0 ? -1 : 1);
      s.ang += passoAng; cm = dt > 0 ? passoAng / dt * CIRC_RODA / 360 : 0;
      if (Math.abs(s.alvo - s.ang) < 1e-9) { s.ang = s.alvo; s.alvo = null; s.vel = 0; servoLiberar(s); }
    } else if (s.vel !== 0) {
      var t = s.tempo > 0 ? Math.min(s.tempo, dt) : dt;
      cm = s.vel / 100 * VEL_LINEAR * (t / dt); s.ang += s.vel / 100 * VEL_LINEAR / CIRC_RODA * 360 * t;
      if (s.tempo > 0) { s.tempo -= dt; if (s.tempo <= 1e-9) { s.tempo = 0; s.vel = 0; servoLiberar(s); } }
    }
    return cm;
  }
  // no Nous, "mover por" e "girar por" só saem na medida certa se o programa disser o diâmetro da roda e a distância entre eixos
  function avisarRodas(girando) {
    var falta = [], padrao = [];
    if (!roda.defD && !roda.avisouD) { falta.push('o diâmetro da roda'); padrao.push('68 mm'); roda.avisouD = true; }
    if (girando && !roda.defB && !roda.avisouB) { falta.push('a distância entre eixos'); padrao.push('137 mm'); roda.avisouB = true; }
    if (!falta.length) return;
    var msg = '⚠️ Defina ' + falta.join(' e ') + ' antes de ' + (girando ? 'girar' : 'mover') + ': o robô de verdade só ' + (girando ? 'gira' : 'anda') + ' na medida certa assim. Aqui usei ' + padrao.join(' e ') + ' (o padrão do Nous).';
    aviso(msg); registrar(msg); try { nota(220, 0.18, 'square'); } catch (e) { /* sem som */ }
  }
  var R = {
    mover: function (dir, valor, un) {
      valor = numero(valor); if (un === 'inch') valor *= 2.54; else if (un === 'seconds') valor *= VEL_LINEAR;
      return iniciar({ tipo: 'linear', resta: dir === 'backward' ? -valor : valor, vel: VEL_LINEAR });
    },
    girar: function (dir, valor, un) {
      valor = numero(valor); if (un === 'rotations') valor *= 360; else if (un === 'seconds') valor *= VEL_GIRO;
      return iniciar({ tipo: 'giro', resta: dir === 'left' ? -valor : valor, vel: VEL_GIRO });
    },
    moverVel: function (dir, valor, un, vel) {
      valor = numero(valor); if (un === 'inch') valor *= 2.54;
      if (ehNous()) { avisarRodas(false); valor *= RODA_NOUS / roda.d; }               // roda configurada errada = distância errada
      return iniciar({ tipo: 'linear', resta: dir === 'backward' ? -valor : valor, vel: Math.max(1, Math.abs(numero(vel, 100))) / 100 * VEL_LINEAR });
    },
    nousRodas: function (qual, mm) { mm = numero(mm); if (mm > 0) { roda[qual] = mm; if (qual === 'd') roda.defD = true; else roda.defB = true; } },
    girarVel: function (dir, valor, un, vel) {
      valor = numero(valor); if (un === 'rotations') valor *= 360;
      if (ehNous()) { avisarRodas(true); } if (ehNous()) valor *= (roda.b / EIXOS_NOUS) * (RODA_NOUS / roda.d); // eixo/roda configurados errados = ângulo errado
      return iniciar({ tipo: 'giro', resta: dir === 'left' ? -valor : valor, vel: Math.max(1, Math.abs(numero(vel, 100))) / 100 * VEL_GIRO });
    },
    iniciarMover: function (dir, vel) {
      var v = numero(vel, 100) / 100 * VEL_LINEAR, g = numero(vel, 100) / 100 * VEL_GIRO * Math.PI / 180 * BITOLA / 2;
      if (dir === 'forward') iniciar({ tipo: 'continuo', vl: v, vr: v }); else if (dir === 'backward') iniciar({ tipo: 'continuo', vl: -v, vr: -v });
      else if (dir === 'left') iniciar({ tipo: 'continuo', vl: -g, vr: g }); else iniciar({ tipo: 'continuo', vl: g, vr: -g });
    },
    pararMover: pararMovimento,
    esperar: function (seg) { return esperarSeg(numero(seg)); },
    imagem: function (nome, seg) { mostrarFigura(IMAGENS[nome] || IMAGENS.olhos); if (seg !== undefined) return esperarSeg(numero(seg)).then(function () { tela.px.fill(0); }); return undefined; },
    texto: function (t) { mostrarTexto(String(t)); },
    pixel: function (x, y, b) { x = Math.round(numero(x)); y = Math.round(numero(y)); if (x >= 0 && x < 16 && y >= 0 && y < 8) { tela.rolagem = null; tela.px[y * 16 + x] = Math.max(0, Math.min(1, numero(b, 100) / 100)); } },
    apagarTela: function () { tela.rolagem = null; tela.px.fill(0); },
    leds: function (r, g, b) { r = Math.max(0, Math.min(255, numero(r))); g = Math.max(0, Math.min(255, numero(g))); b = Math.max(0, Math.min(255, numero(b))); robo.led = (r || g || b) ? [r, g, b] : null; },
    nota: function (n, batidas) { var seg = Math.max(0, numero(batidas, 0.25)) * 60 / som.tempo; nota(freqMidi(numero(n, 60)), Math.max(0.05, seg / cfg.turbo), 'triangle'); return esperarSeg(seg); },
    falar: function (t) {
      registrar('🗣 ' + t);
      if (!cfg.som || !window.speechSynthesis || !window.SpeechSynthesisUtterance) return;
      try { var u = new window.SpeechSynthesisUtterance(String(t)); u.lang = 'pt-BR'; window.speechSynthesis.speak(u); } catch (e) { /* sem voz */ }
    },
    silencio: silenciar,
    cor: function (nome) { return classificarCor(corSob(robo.x, robo.y)) === nome; },
    distancia: distanciaFrente,
    rgb: function (i) { return corSob(robo.x, robo.y)[i]; },
    cronometro: function () { return Math.round(exec.crono * 10) / 10; },
    zerarCronometro: function () { exec.crono = 0; },
    servoVel: function (idx, vals) { var v = lista(vals); lista(idx).forEach(function (i, k) { var s = servo(i); s.vel = Math.max(-100, Math.min(100, v.length ? v[Math.min(k, v.length - 1)] : 0)); s.alvo = null; s.tempo = 0; servoLiberar(s); }); servoAcordar(); },
    servoAddVel: function (idx, vals) { var v = lista(vals); lista(idx).forEach(function (i, k) { var s = servo(i); s.vel = Math.max(-100, Math.min(100, s.vel + (v.length ? v[Math.min(k, v.length - 1)] : 0))); s.alvo = null; s.tempo = 0; servoLiberar(s); }); servoAcordar(); },
    servoParar: function (idx) { lista(idx).forEach(function (i) { var s = servo(i); s.vel = 0; s.alvo = null; s.tempo = 0; servoLiberar(s); }); },
    servoPos: function (idx, vals) { var v = lista(vals); lista(idx).forEach(function (i, k) { var s = servo(i); s.alvo = v.length ? v[Math.min(k, v.length - 1)] : 0; s.vAlvo = degPorSeg(Math.max(Math.abs(s.vel), ANG_PADRAO)); s.vel = 0; s.tempo = 0; }); servoAcordar(); },
    servoAddAng: function (idx, vals) { var v = lista(vals), ids = lista(idx); ids.forEach(function (i, k) { var s = servo(i); s.alvo = s.ang + (v.length ? v[Math.min(k, v.length - 1)] : 0); s.vAlvo = degPorSeg(Math.max(Math.abs(s.vel), ANG_PADRAO)); s.vel = 0; s.tempo = 0; }); servoAcordar(); return servoEsperar(ids); },
    servoZeroVoltar: function (idx, sentido) { var ids = lista(idx); ids.forEach(function (i) { var s = servo(i); s.alvo = sentido === '1' ? Math.floor(s.ang / 360 + 1e-9) * 360 : Math.ceil(s.ang / 360 - 1e-9) * 360; s.alvo = Math.abs(s.alvo) < 1e-9 ? 0 : s.alvo; s.vAlvo = degPorSeg(Math.max(Math.abs(s.vel), ANG_PADRAO)); s.vel = 0; s.tempo = 0; }); servoAcordar(); return servoEsperar(ids); },
    servoTempo: function (idx, angs, mss) {
      var v = lista(angs), t = lista(mss), ids = lista(idx);
      ids.forEach(function (i, k) { var s = servo(i), alvo = v.length ? v[Math.min(k, v.length - 1)] : 0, ms = t.length ? t[Math.min(k, t.length - 1)] : 0;
        s.alvo = alvo; s.vAlvo = ms > 0 ? Math.abs(alvo - s.ang) / (ms / 1000) : degPorSeg(ANG_PADRAO); s.vel = 0; s.tempo = 0; });
      servoAcordar(); return servoEsperar(ids);
    },
    servoRodar: function (idx, vals, un, vels) {
      var v = lista(vals), sp = lista(vels), ids = lista(idx);
      ids.forEach(function (i, k) { var s = servo(i), q = v.length ? v[Math.min(k, v.length - 1)] : 0, pc = sp.length ? sp[Math.min(k, sp.length - 1)] : 0, sg = pc < 0 ? -1 : 1;
        if (un === 'seconds') { s.vel = Math.max(-100, Math.min(100, pc)); s.alvo = null; s.tempo = Math.max(0, q); }
        else { s.alvo = s.ang + sg * q * (un === 'rotations' ? 360 : 1); s.vAlvo = degPorSeg(pc || ANG_PADRAO); s.vel = 0; s.tempo = 0; } });
      servoAcordar(); return servoEsperar(ids);
    },
    servoZero: function (idx) { lista(idx).forEach(function (i) { servo(i).ang = 0; }); },
    servoGet: function (idx, campo) { var a = lista(idx); return a.length ? Math.round(servo(a[0])[campo] * 100) / 100 : 0; },
    pararEste: function () { throw PARAR; }
  };
  // cada execução recebe a sua própria "ficha": um programa parado nunca volta a andar
  function comandosDe(ficha) {
    var r = Object.create(R);
    r.bloco = function (id) { vivo(ficha); if (ws) ws.highlightBlock(id); };
    r.seta = function (i) { vivo(ficha); destacarSeta(i); };
    r.tique = function () { vivo(ficha); return new Promise(function (ok) { proximoQuadro.push(ok); }).then(function () { vivo(ficha); }); };
    r.pararTudo = function () { if (exec.ficha === ficha) pararPrograma(); throw PARAR; };
    return r;
  }

  /* ---------- Execução do programa ---------- */
  function rodarPilha(p, ficha) {
    p.ativa = true;
    Promise.resolve().then(function () { return p.fn(); }).catch(function (e) { if (e !== PARAR) { console.error(e); aviso('Erro no programa: ' + (e && e.message ? e.message : e)); } })
      .then(function () { p.ativa = false; if (exec.ficha === ficha) verificarFim(); });
  }
  function verificarFim() {
    if (!exec.rodando) return;
    var temEvento = exec.pilhas.some(function (p) { return p.cond; }), ativa = exec.pilhas.some(function (p) { return p.ativa; });
    if (!ativa && !temEvento) pararPrograma(true);
  }
  function dispararEventos() {
    if (!exec.rodando) return;
    var ficha = exec.ficha;
    exec.pilhas.forEach(function (p) {
      if (!p.cond || p.avaliando) return;
      p.avaliando = true;
      p.cond().then(function (v) { v = !!v; if (v && !p.anterior && !p.ativa && exec.ficha === ficha) rodarPilha(p, ficha); p.anterior = v; p.avaliando = false; }, function () { p.avaliando = false; });
    });
  }
  function executar() {
    pararPrograma(); audio();
    var pilhas, ficha = { cancelada: false }, cmds = comandosDe(ficha);
    try { pilhas = ehSetas() ? setasPilhas(cmds) : window.RoboBlocos.compilar(ws, cmds); } catch (e) { console.error(e); aviso('Não consegui montar o programa: ' + e.message); return; }
    if (!pilhas.length) { aviso(ehSetas() ? 'Aperte as setas do controle para montar o programa e depois o ▶ do meio.' : 'Comece o programa com um bloco de Eventos, como "quando o robô iniciar".'); return; }
    if (!cfg.aberto) alternarPainel(true);
    if (!ehSetas() && !canetaAtual()) aviso('Dica: escolha uma caneta nas Canetas, senão o robô anda sem desenhar.');
    if (faseAtual()) { apagarDesenho(); reiniciar(); }
    servos = {}; roda = { d: RODA_NOUS, b: EIXOS_NOUS, defD: false, defB: false, avisouD: false, avisouB: false }; exec.ficha = ficha; exec.pilhas = pilhas; exec.rodando = true; exec.crono = 0;
    ui.btPlay.classList.add('rodando'); if (ui.stPlay) ui.stPlay.classList.add('rodando');
    pilhas.forEach(function (p) { if (!p.cond) rodarPilha(p, ficha); });
    verificarFim();
  }
  function pararPrograma(natural) {
    if (exec.ficha) exec.ficha.cancelada = true;
    exec.ficha = null; exec.rodando = false; exec.pilhas = [];
    var esp = exec.esperas; exec.esperas = []; esp.forEach(function (e) { e.ok(); });
    var q = proximoQuadro; proximoQuadro = []; q.forEach(function (ok) { ok(); });
    if (!natural) { pararMovimento(); silenciar(); }
    if (ws) ws.highlightBlock(null);
    if (ui.btPlay) ui.btPlay.classList.remove('rodando'); if (ui.stPlay) ui.stPlay.classList.remove('rodando');
    destacarSeta(-1);
    if (natural && faseAtual()) verificar(true);
  }

  /* ---------- Fases: o molde e a conferência do desenho ---------- */
  // vértices da forma, em cm: começa no ponto de saída, olhando para a direita, e sempre gira para a direita
  function moldeDe(f) {
    var x = INI_FASE.x, y = INI_FASE.y, dir = INI_FASE.dir, v = [[x, y]];
    f.lados.forEach(function (l) { var r = dir * Math.PI / 180; x += Math.sin(r) * l; y += Math.cos(r) * l; v.push([x, y]); dir += f.ang; });
    return v;
  }
  function distSeg(px, py, a, b) {
    var dx = b[0] - a[0], dy = b[1] - a[1], t = dx * dx + dy * dy ? ((px - a[0]) * dx + (py - a[1]) * dy) / (dx * dx + dy * dy) : 0;
    t = Math.max(0, Math.min(1, t)); return Math.hypot(px - (a[0] + t * dx), py - (a[1] + t * dy));
  }
  function amostrar(pontos, passo) {
    var out = [], i, a, b, n, k, len;
    for (i = 0; i + 1 < pontos.length; i++) {
      a = pontos[i]; b = pontos[i + 1]; len = Math.hypot(b[0] - a[0], b[1] - a[1]); n = Math.max(1, Math.ceil(len / passo));
      for (k = 0; k < n; k++) out.push([a[0] + (b[0] - a[0]) * k / n, a[1] + (b[1] - a[1]) * k / n]);
    }
    if (pontos.length) out.push(pontos[pontos.length - 1]);
    return out;
  }
  function distAoConjunto(p, polis) {
    var m = Infinity, i, k;
    for (i = 0; i < polis.length; i++) { var pts = polis[i]; if (pts.length === 1) m = Math.min(m, Math.hypot(p[0] - pts[0][0], p[1] - pts[0][1])); for (k = 0; k + 1 < pts.length; k++) m = Math.min(m, distSeg(p[0], p[1], pts[k], pts[k + 1])); }
    return m;
  }
  // confere: quantos pontos do molde foram riscados e quanto foi riscado fora dele
  function conferir() {
    var f = faseAtual(); if (!f) return null;
    var molde = moldeDe(f), alvo = amostrar(molde, 0.4), feito = tracos.map(function (t) { return t.pts; }), riscado = [], certos = 0, i, fora = 0;
    feito.forEach(function (p) { riscado = riscado.concat(amostrar(p, 0.4)); });
    for (i = 0; i < alvo.length; i++) if (distAoConjunto(alvo[i], feito) <= 0.7) certos++;
    for (i = 0; i < riscado.length; i++) if (distAoConjunto(riscado[i], [molde]) > 0.9) fora++;
    var pctFora = riscado.length ? fora / riscado.length : 0, acerto = Math.round(100 * certos / alvo.length);
    var estrelas = acerto >= 95 && pctFora <= 0.06 ? 3 : acerto >= 80 && pctFora <= 0.2 ? 2 : acerto >= 50 ? 1 : 0;
    return { acerto: acerto, fora: Math.round(pctFora * 100), estrelas: estrelas, vazio: !riscado.length };
  }
  function contarBlocos() { if (ehSetas()) return setas.length; try { return ws.getAllBlocks(false).filter(function (b) { return !b.isShadow() && b.isEnabled(); }).length; } catch (e) { return 0; } }
  function verificar(auto) {
    var f = faseAtual(); if (!f) { aviso('No Modo Livre não tem nota: desenhe o que quiser!', true); return; }
    var r = conferir(); if (!r) return;
    if (r.vazio) { aviso(canetaAtual() ? 'Ainda não tem desenho. Aperte o Desenhar!' : 'Escolha uma caneta antes de desenhar.'); return; }
    jogo.acerto = r; jogo.ok = r.estrelas > 0;
    var q = contarBlocos(), unid = ehSetas() ? (q === 1 ? ' comando' : ' comandos') : (q === 1 ? ' bloco' : ' blocos');
    ui.placar.textContent = '★★★'.slice(0, r.estrelas) + '☆☆☆'.slice(0, 3 - r.estrelas) + ' · acerto ' + r.acerto + '%' + (r.fora > 3 ? ' · ' + r.fora + '% do traço ficou fora do molde' : '') + ' · ' + q + unid;
    if (r.estrelas === 3) { aviso('🎉 ' + f.nome + ' perfeito!', true); tocarVitoria(); }
    else if (r.estrelas > 0) { aviso('Quase! ' + (r.fora > 3 ? 'Sobrou traço fora do molde.' : 'Falta cobrir um pedaço do molde.'), true); nota(freqMidi(72), 0.14, 'triangle'); }
    else { aviso('Ainda não é um ' + f.nome.toLowerCase() + '. Veja a dica e tente de novo.'); nota(freqMidi(55), 0.18, 'square'); }
    void auto;
  }
  function posicaoInicial() { return faseAtual() ? INI_FASE : INI_LIVRE; }
  function reiniciar() {
    pararMovimento(); silenciar(); var p = posicaoInicial();
    robo.x = p.x; robo.y = p.y; robo.dir = p.dir; robo.led = null; traco = null; mostrarFigura(IMAGENS.olhos);
  }
  function maxSetas() { var f = faseAtual(); return f ? f.lim : 32; }
  function anguloSeta() { var f = faseAtual(); return f ? f.ang : 90; }
  function escolherFase(n) {
    if (n && robocfg().fases.indexOf(n) < 0) return;
    if (exec.rodando) pararPrograma();
    cfg.fase = n; salvar('fase', n); apagarDesenho(); aviso('');
    if (setas.length > maxSetas()) { setas = setas.slice(0, maxSetas()); salvarSetas(); }
    reiniciar(); atualizarFases(); if (ui.stLista) desenharSetas(false);
  }
  function escolherCaneta(id) {
    cfg.caneta = cfg.caneta === id ? '' : id; salvar('caneta', cfg.caneta); traco = null; atualizarCanetas();
    audio(); nota(freqMidi(cfg.caneta ? 76 : 64), 0.06, 'triangle');
  }

  /* ---------- Interface ---------- */
  function el(tag, attrs, filhos) {
    var e = document.createElement(tag);
    Object.keys(attrs || {}).forEach(function (k) {
      if (k === 'style') e.style.cssText = attrs[k]; else if (k === 'text') e.textContent = attrs[k];
      else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), attrs[k]); else e.setAttribute(k, attrs[k]);
    });
    (filhos || []).forEach(function (f) { e.appendChild(f); });
    return e;
  }
  function aviso(t, ok) { if (!ui.aviso) return; ui.aviso.textContent = t || ''; ui.aviso.style.color = ok ? '#0a8a4a' : '#b45309'; }
  function registrar(t) { if (ui.log) ui.log.textContent = t; }
  function botao(txt, titulo, fn, classe) { var a = { text: txt, title: titulo, onclick: fn, type: 'button' }; if (classe) a['class'] = classe; return el('button', a); }

  function svgCaneta(cor) {
    return '<svg viewBox="0 0 24 76" width="24" height="76" aria-hidden="true"><path d="M5 2h14a3 3 0 0 1 3 3v9H2V5a3 3 0 0 1 3-3z" fill="' + cor + '"/><rect x="2" y="14" width="20" height="38" fill="#f3f4f6" stroke="#b8bcc4"/>' +
      '<rect x="2" y="26" width="20" height="9" fill="' + cor + '"/><path d="M2 52h20l-8 20h-4z" fill="#e6e8ec" stroke="#b8bcc4"/><path d="M10 64h4l-2 8z" fill="' + cor + '"/></svg>';
  }
  function criarPainel() {
    ui.sim = document.getElementById('sim'); ui.aba = document.getElementById('aba');
    ui.btPlay = document.getElementById('bt-play'); ui.btStop = document.getElementById('bt-stop');
    ui.btPlay.addEventListener('click', executar);
    ui.btStop.addEventListener('click', function () { pararPrograma(); });
    document.getElementById('bt-mais').addEventListener('click', function () { ws.zoomCenter(1); });
    document.getElementById('bt-menos').addEventListener('click', function () { ws.zoomCenter(-1); });
    document.getElementById('bt-centro').addEventListener('click', function () { ws.zoomToFit(); if (ws.scale > 1.1) ws.setScale(1); ws.scrollCenter(); });
    ui.aba.addEventListener('click', function () { alternarPainel(); });

    ui.canvas = el('canvas', { 'class': 'mat', title: 'Folha de desenho' });
    ui.face = el('canvas', { 'class': 'face', width: 168, height: 88, title: 'Telinha do rosto do robô' });
    ui.chipPos = el('span', { 'class': 'chip', title: 'Onde o robô está (em cm, a partir do centro da folha)' });
    ui.seta = el('i', { 'class': 'seta', text: '➤' });
    ui.chipDir = el('span', { 'class': 'chip', title: 'Para onde o robô olha' }, [ui.seta]);
    ui.bolaCor = el('i', { 'class': 'bola' }); ui.nomeCor = el('b', {});
    ui.chipCor = el('span', { 'class': 'chip', title: 'Caneta que está no robô' }, [ui.bolaCor, ui.nomeCor]);
    ui.log = el('div', { 'class': 'log' });
    ui.aviso = el('div', { 'class': 'aviso' }); ui.placar = el('div', { 'class': 'placar' });
    ui.legenda = el('div', { 'class': 'legenda' });
    ui.dica = el('div', { 'class': 'dica-fase' });

    ui.fases = el('div', { 'class': 'fases' });
    ui.rack = el('div', { 'class': 'rack' }, [el('div', { 'class': 'rack-t', text: 'Canetas' })]);
    ui.canetas = CANETAS.map(function (c) {
      var b = el('button', { type: 'button', 'class': 'caneta', title: 'Caneta ' + c.nome + ' — toque para pôr no robô ou tirar', 'data-caneta': c.id });
      b.innerHTML = svgCaneta(c.cor); b.addEventListener('click', function () { escolherCaneta(c.id); }); ui.rack.appendChild(b); return b;
    });

    ui.btVoltar = botao('⟲ Voltar ao início', 'Leva o robô de volta para o ponto de saída (o desenho fica)', function () { pararPrograma(); reiniciar(); }, 'grande');
    ui.btApagar = botao('🗑 Apagar', 'Apaga o desenho da folha', function () { pararPrograma(); apagarDesenho(); aviso(''); reiniciar(); }, 'icone largo');
    ui.btVerificar = botao('✔ Conferir', 'Confere o desenho com o molde da fase', function () { verificar(false); }, 'icone largo');
    ui.btTurbo = botao('', 'Velocidade da simulação', function () { cfg.turbo = cfg.turbo === 1 ? 2 : cfg.turbo === 2 ? 4 : 1; salvar('turbo', cfg.turbo); marcar(); }, 'icone largo');
    ui.btSom = botao('', 'Ligar ou desligar o som', function () { cfg.som = !cfg.som; salvar('som', cfg.som); if (!cfg.som) silenciar(); else audio(); marcar(); }, 'icone');
    ui.robos = ROBOS.map(function (r) {
      return el('button', { 'class': 'robo', type: 'button', title: 'Usar o ' + r.nome, 'data-robo': r.id, onclick: function () { cfg.robo = r.id; salvar('robo', cfg.robo); carregarRobo(); } },
        [el('img', { src: r.img, alt: '' }), el('span', { text: r.nome })]);
    });
    ui.escolhaRobo = el('div', { 'class': 'escolha-robo' }, [el('div', { 'class': 'titulo', text: '🤖 Escolha o robô desenhista' }), el('div', { 'class': 'robos' }, ui.robos)]);
    ui.btMenor = botao('−', 'Diminuir o painel', function () { redimensionar(-1); });
    ui.btMaior = botao('+', 'Aumentar o painel', function () { redimensionar(1); });

    ui.sim.appendChild(el('div', { 'class': 'top' }, [el('span', { text: '🎨 Folha de Desenho' }), ui.btMenor, ui.btMaior]));
    ui.sim.appendChild(el('div', { 'class': 'corpo' }, [
      ui.fases, ui.legenda,
      el('div', { 'class': 'moldura-d' }, [ui.rack, el('div', { 'class': 'moldura' }, [ui.canvas])]),
      el('div', { 'class': 'status' }, [ui.face, el('div', { 'class': 'chips' }, [ui.chipPos, ui.chipDir, ui.chipCor])]),
      ui.aviso, ui.placar, ui.dica, ui.log,
      el('div', { 'class': 'acoes' }, [ui.btVoltar, ui.btApagar, ui.btVerificar, ui.btTurbo, ui.btSom]),
      ui.escolhaRobo
    ]));
    window.addEventListener('resize', ajustar);
    atualizarFases(); atualizarCanetas(); ajustar(); marcar();
  }
  function atualizarFases() {
    if (!ui.fases) return;
    var r = robocfg(), f = faseAtual();
    ui.fases.textContent = '';
    ui.fases.appendChild(botao('✏️ Livre', 'Modo Livre: desenhe o que quiser', function () { escolherFase(0); }, 'fase' + (cfg.fase === 0 ? ' ativo' : '')));
    r.fases.forEach(function (n) {
      var d = FASES[n - 1];
      ui.fases.appendChild(botao(d.ic + ' ' + d.nome, 'Fase: desenhar o ' + d.nome.toLowerCase(), function () { escolherFase(n); }, 'fase' + (cfg.fase === n ? ' ativo' : '')));
    });
    ui.legenda.textContent = f ? '📏 Fase ' + (r.fases.indexOf(f.id) + 1 || '') + ' · ' + f.nome + ' — ' + (f.id === 4 ? 'lados de 20 cm e 10 cm' : 'lados de ' + f.lados[0] + ' cm') + ', giro de ' + f.ang + '°'
      : '📏 Modo Livre · desenhe o que quiser (1 quadrado = 1 cm)';
    ui.dica.textContent = f ? '💡 ' + DICAS[r.dicas][f.id - 1] : '';
    ui.dica.style.display = f ? '' : 'none';
    ui.btVerificar.style.display = f ? '' : 'none';
  }
  function atualizarCanetas() {
    if (!ui.canetas) return;
    ui.canetas.forEach(function (b) { b.classList.toggle('ativa', b.dataset.caneta === cfg.caneta); });
    var c = canetaAtual(); if (ui.bolaCor) { ui.bolaCor.style.background = c ? c.cor : '#fff'; ui.nomeCor.textContent = c ? c.nome : 'sem caneta'; }
  }
  function marcar() { ui.btTurbo.textContent = '⏩ ' + cfg.turbo + 'x'; ui.btSom.textContent = cfg.som ? '🔊' : '🔇'; }
  function alternarPainel(abrir) { cfg.aberto = abrir === undefined ? !cfg.aberto : abrir; salvar('aberto', cfg.aberto); ajustar(); }
  function redimensionar(s) {
    var tam = [340, 480, 600, 740], i = tam.indexOf(cfg.largura); if (i < 0) i = 1;
    i = Math.max(0, Math.min(tam.length - 1, i + s)); cfg.largura = tam[i]; salvar('largura', cfg.largura); ajustar();
  }
  function ajustar() {
    var estreito = window.innerWidth < 760 || window.innerHeight < 520, setasModo = ehSetas(), aberto = cfg.aberto || setasModo;
    var emColuna = estreito && setasModo;
    var area = document.getElementById('area');
    area.classList.toggle('estreito', estreito); area.classList.toggle('coluna', emColuna);
    var w = estreito ? Math.max(220, Math.min(560, window.innerWidth - 60)) : Math.max(220, Math.min(cfg.largura, Math.round(window.innerWidth * 0.55) - 20));
    if (emColuna) w = Math.max(200, Math.min(window.innerWidth - 40, Math.round(window.innerHeight * 0.3 * MAT.w / MAT.h)));
    var wc = Math.max(150, w - 76);
    ui.aba.style.right = estreito ? (aberto ? (w + 20) + 'px' : '0px') : '';
    ui.canvas.width = MAT.w; ui.canvas.height = MAT.h;
    ui.canvas.style.width = wc + 'px'; ui.canvas.style.height = Math.round(wc * MAT.h / MAT.w) + 'px';
    ui.rack.style.height = Math.round(wc * MAT.h / MAT.w) + 'px';
    ui.sim.style.width = emColuna ? '100%' : (aberto ? (w + 20) + 'px' : '0px');
    ui.sim.classList.toggle('fechado', !aberto);
    ui.aba.textContent = aberto ? '›' : '‹';
    ui.aba.title = aberto ? 'Fechar a folha' : 'Abrir a folha';
    if (ws) { window.Blockly.svgResize(ws); setTimeout(function () { window.Blockly.svgResize(ws); }, 220); }
  }

  function px(x) { return MAT.ax + x * MAT.ppcX; }
  function py(y) { return MAT.ay - y * MAT.ppcY; }
  function desenharPapel(g) {
    var i, k = PPC;
    g.fillStyle = '#dfe3e8'; g.fillRect(0, 0, MAT.w, MAT.h);
    for (i = Math.ceil(PAP.x0); i <= PAP.x1; i++) { g.strokeStyle = i % 5 === 0 ? '#aab2bc' : '#c3c9d1'; g.lineWidth = i % 5 === 0 ? 1.6 : 1; g.beginPath(); g.moveTo(px(i), 0); g.lineTo(px(i), MAT.h); g.stroke(); }
    for (i = Math.ceil(PAP.y0); i <= PAP.y1; i++) { g.strokeStyle = i % 5 === 0 ? '#aab2bc' : '#c3c9d1'; g.lineWidth = i % 5 === 0 ? 1.6 : 1; g.beginPath(); g.moveTo(0, py(i)); g.lineTo(MAT.w, py(i)); g.stroke(); }
    g.fillStyle = 'rgba(80,90,105,.7)'; g.font = 'bold ' + Math.round(k * 0.5) + 'px Arial'; g.textAlign = 'left'; g.textBaseline = 'top';
    g.fillText('1 quadrado = 1 cm', 8, MAT.h - k * 0.9);
  }
  function desenharMolde(g) {
    var f = faseAtual(); if (!f) return;
    var m = moldeDe(f), i;
    g.save(); g.lineWidth = 9; g.lineJoin = 'round'; g.lineCap = 'round'; g.strokeStyle = 'rgba(70,80,95,.55)'; g.setLineDash([16, 12]);
    g.beginPath(); g.moveTo(px(m[0][0]), py(m[0][1])); for (i = 1; i < m.length; i++) g.lineTo(px(m[i][0]), py(m[i][1])); g.stroke(); g.setLineDash([]);
    var sx = px(m[0][0]), sy = py(m[0][1]);                                   // a bandeirinha do ponto de saída
    g.fillStyle = '#1fa64a'; g.beginPath(); g.arc(sx, sy, 11, 0, Math.PI * 2); g.fill();
    g.fillStyle = '#fff'; g.beginPath(); g.moveTo(sx - 3, sy - 6); g.lineTo(sx + 6, sy - 2); g.lineTo(sx - 3, sy + 2); g.closePath(); g.fill(); g.fillRect(sx - 4, sy - 6, 2, 12);
    g.restore();
  }
  function desenharCaneta(g, x, y, cor) {                                       // a caneta presa no robô: a ponta fica no centro
    g.save(); g.translate(x, y); g.rotate(Math.PI / 5);
    g.fillStyle = '#f3f4f6'; g.strokeStyle = '#8b919a'; g.lineWidth = 2; g.beginPath(); g.rect(-6, -62, 12, 46); g.fill(); g.stroke();
    g.fillStyle = cor; g.fillRect(-6, -48, 12, 11); g.beginPath(); g.moveTo(-6, -16); g.lineTo(6, -16); g.lineTo(0, 0); g.closePath(); g.fill();
    g.beginPath(); g.moveTo(-6, -62); g.lineTo(6, -62); g.lineTo(6, -68); g.lineTo(-6, -68); g.closePath(); g.fill(); g.restore();
  }
  function desenhar() {
    var g = ui.canvas.getContext('2d'), i, k = PPC / 20;
    g.clearRect(0, 0, MAT.w, MAT.h);
    desenharPapel(g); desenharMolde(g);
    g.lineJoin = 'round'; g.lineCap = 'round';
    tracos.forEach(function (t) {
      g.strokeStyle = t.cor; g.lineWidth = 7;
      g.beginPath(); g.moveTo(px(t.pts[0][0]), py(t.pts[0][1])); for (i = 1; i < t.pts.length; i++) g.lineTo(px(t.pts[i][0]), py(t.pts[i][1]));
      if (t.pts.length === 1) g.lineTo(px(t.pts[0][0]) + 0.1, py(t.pts[0][1])); g.stroke();
    });
    var tam = TAM_ROBO * PPC, cor = canetaAtual();
    g.save(); g.translate(px(robo.x), py(robo.y)); g.rotate((robo.dir + (robo.balanco || 0)) * Math.PI / 180);
    if (robo.led) {
      g.shadowColor = 'rgb(' + robo.led.join(',') + ')'; g.shadowBlur = 40 * k;
      g.fillStyle = 'rgba(' + robo.led.join(',') + ',.55)'; g.beginPath(); g.arc(0, 0, tam * 0.56, 0, Math.PI * 2); g.fill(); g.shadowBlur = 0;
    }
    g.shadowColor = 'rgba(0,0,0,.4)'; g.shadowBlur = 10; g.shadowOffsetY = 3;
    if (imgRobo.complete && imgRobo.naturalWidth) g.drawImage(imgRobo, -tam / 2, -tam / 2, tam, tam);
    else { g.fillStyle = '#f0841c'; g.fillRect(-tam / 2, -tam / 2, tam, tam); }
    g.shadowColor = 'transparent'; g.fillStyle = '#fff'; g.strokeStyle = '#222'; g.lineWidth = 3;
    g.beginPath(); g.moveTo(0, -tam / 2 - 16); g.lineTo(-10, -tam / 2 - 2); g.lineTo(10, -tam / 2 - 2); g.closePath(); g.fill(); g.stroke();
    g.restore();
    if (cor) desenharCaneta(g, px(robo.x), py(robo.y), cor.cor);
    else { g.strokeStyle = 'rgba(40,40,40,.6)'; g.lineWidth = 3; g.beginPath(); g.arc(px(robo.x), py(robo.y), 7, 0, Math.PI * 2); g.stroke(); }

    var f = ui.face.getContext('2d'); f.clearRect(0, 0, 168, 88);
    for (var y = 0; y < 8; y++) for (var x = 0; x < 16; x++) {
      var v = tela.px[y * 16 + x];
      f.fillStyle = v > 0 ? 'rgba(120,225,255,' + (0.25 + 0.75 * v) + ')' : '#232b36';
      f.beginPath(); f.arc(9 + x * 10, 9 + y * 10, 3.8, 0, Math.PI * 2); f.fill();
    }
    if (robo.led) { f.fillStyle = 'rgb(' + robo.led.join(',') + ')'; f.fillRect(0, 84, 168, 4); }
    ui.chipPos.textContent = '📍 ' + String(Math.round(robo.x * 10) / 10).replace('.', ',') + ' ; ' + String(Math.round(robo.y * 10) / 10).replace('.', ',') + ' cm';
    ui.seta.style.transform = 'rotate(' + (robo.dir - 90) + 'deg)'; ui.chipDir.title = 'Olhando para o ' + nomeDir(robo.dir);
  }

  var ultimo = 0;
  function quadro(agora) {
    var dt = Math.min(0.05, (agora - ultimo) / 1000 || 0); ultimo = agora;
    var q = proximoQuadro; proximoQuadro = []; q.forEach(function (ok) { ok(); });
    passo(dt); desenhar();
    window.requestAnimationFrame(quadro);
  }

  /* ---------- Modo setas (Matata e Tale): o programa é feito apertando o controle do robô ---------- */
  var setas = carregar('setas', []).filter(function (c) { return 'FBLRMDV'.indexOf(c) >= 0; }).slice(0, 32),
    repet = Math.max(1, Math.min(4, Math.round(Number(carregar('setasRep', 1))) || 1)); // quantas vezes o programa todo se repete (1 a 4)
  // h = onde fica o botão na imagem (esq., topo, larg., alt. em fração) · i = centro e lado do ícone (para a miniatura) · r = canto arredondado
  var CONTROLES = {
    matata: { img: A.controleMatata, bts: [
      { c: 'F', h: [0.3732, 0.1435, 0.2472, 0.2328], i: [0.4968, 0.26, 0.23], r: '8%' },
      { c: 'B', h: [0.3732, 0.626, 0.2472, 0.2392], i: [0.4968, 0.7456, 0.23], r: '8%' },
      { c: 'L', h: [0.1316, 0.1714, 0.2313, 0.323], i: [0.2592, 0.3549, 0.17], r: '14% 8% 8% 8%' },
      { c: 'R', h: [0.6324, 0.1714, 0.2209, 0.323], i: [0.7297, 0.3549, 0.17], r: '8% 14% 8% 8%' },
      { c: 'M', h: [0.1316, 0.5064, 0.2313, 0.327], i: [0.2695, 0.63, 0.17], r: '8% 8% 8% 14%' },
      { c: 'X', h: [0.6324, 0.5064, 0.2209, 0.323], i: [0.7257, 0.638, 0.17], r: '8% 8% 14% 8%' },
      { c: 'P', h: [0.3732, 0.3883, 0.2472, 0.2257], r: '8%' }] },
    tale: { img: A.controleTale, bts: [
      { c: 'D', h: [0.1486, 0.1905, 0.1656, 0.1656], i: [0.2314, 0.2733, 0.16], r: '50%' },
      { c: 'F', h: [0.3872, 0.1708, 0.2236, 0.1889], i: [0.499, 0.265, 0.18], r: '38%' },
      { c: 'V', h: [0.6853, 0.1905, 0.1656, 0.1656], i: [0.7645, 0.2733, 0.16], r: '50%' },
      { c: 'L', h: [0.1294, 0.4286, 0.1889, 0.221], i: [0.2236, 0.5383, 0.17], r: '40%' },
      { c: 'P', h: [0.3872, 0.4286, 0.2236, 0.2225], r: '16%' },
      { c: 'R', h: [0.679, 0.4322, 0.1915, 0.2225], i: [0.7738, 0.5435, 0.17], r: '40%' },
      { c: 'T', h: [0.1486, 0.7295, 0.1656, 0.1656], i: [0.2314, 0.81, 0.16], r: '50%' },
      { c: 'B', h: [0.3882, 0.7236, 0.2236, 0.19], i: [0.5, 0.823, 0.17], r: '38%' },
      { c: 'X', h: [0.6873, 0.7295, 0.1656, 0.1656], i: [0.766, 0.81, 0.16], r: '50%' }] }
  };
  var NOME_SETA = { F: 'Frente (1 quadrante)', B: 'Trás (1 quadrante)', L: 'Girar à esquerda (90°)', R: 'Girar à direita (90°)', M: 'Música', D: 'Dança', V: 'Gravar som', T: 'Repetir o programa (cada toque: 1×, 2×, 3×, 4×)', P: 'Executar (▶)', X: 'Apagar o último (segure para apagar tudo)' };
  var SOM_SETA = { F: 72, B: 55, L: 67, R: 69, M: 76, D: 79, V: 64, T: 60, X: 48, P: 84 };
  // luzinhas do controle: Matata = anel de 12 bolinhas; Tale = 8 bolinhas na cabeça + 4 tracinhos (repetições)
  var COR_SETA = {
    matata: { F: '#3aa300', B: '#ee1c1c', L: '#ffd500', R: '#0099e6', M: '#7a2f96', D: '#7a2f96', V: '#7a2f96' },
    tale: { F: '#a8e04c', B: '#ff4a50', L: '#fcd530', R: '#62a8e6', M: '#d336a8', D: '#d336a8', V: '#4cc7d0' }
  };
  var LUZES = {
    matata: { pontos: (function () { var v = []; for (var k = 0; k < 12; k++) { var t = k * Math.PI / 6; v.push([0.5 + 0.4266 * Math.sin(t), 0.5 - 0.4266 * Math.cos(t)]); } return v; })(), d: 0.036, base: true },
    tale: { pontos: [[0.2422, 0.133], [0.3059, 0.133], [0.3706, 0.133], [0.4353, 0.133], [0.5, 0.133], [0.5647, 0.133], [0.6294, 0.133], [0.6941, 0.133]], d: 0.034, base: false,
      tracos: [[0.3877, 0.0921], [0.4576, 0.0921], [0.5269, 0.0921], [0.5974, 0.0921]], tw: 0.043, th: 0.015 }
  };
  // Matata: a faixa de 12 encaixes na parte de baixo do tapete mostra as peças na ordem em que foram apertadas
  var pecas = new Image(), imgCtlM = new Image(), setaAtual = -1;
  pecas.src = A.pecasMatata; imgCtlM.src = A.controleMatata;
  var PECA = { R: 0, F: 1, L: 2, B: 3 };
  function desenharTrilha(g) {
    if (cfg.robo !== 'matata' || !setas.length || !pecas.complete || !pecas.naturalWidth) return;
    var n = 12, ini = Math.max(0, setas.length - n), t = 42, j, c, cx, cy = 716, k;
    for (j = 0; j < n && ini + j < setas.length; j++) {
      c = setas[ini + j]; cx = 96 + 43.4 * j; k = ini + j;
      if (k === setaAtual) { g.save(); g.shadowColor = '#ffb300'; g.shadowBlur = 14; g.fillStyle = 'rgba(255,179,0,.55)'; g.beginPath(); g.arc(cx, cy, t * 0.56, 0, Math.PI * 2); g.fill(); g.restore(); }
      if (PECA[c] !== undefined) g.drawImage(pecas, PECA[c] * 96, 0, 96, 96, cx - t / 2, cy - t / 2, t, t);
      else if (imgCtlM.complete && imgCtlM.naturalWidth) {          // música: peça roxa com o ícone do botão
        var d = CONTROLES.matata.bts.filter(function (x) { return x.c === 'M'; })[0], W = imgCtlM.naturalWidth, s = d.i[2] * W;
        g.save(); g.beginPath(); if (g.roundRect) g.roundRect(cx - t / 2 + 2, cy - t / 2 + 2, t - 4, t - 4, 9); else g.rect(cx - t / 2 + 2, cy - t / 2 + 2, t - 4, t - 4); g.clip();
        g.drawImage(imgCtlM, (d.i[0] - d.i[2] / 2) * W, (d.i[1] - d.i[2] / 2) * W, s, s, cx - t / 2 + 2, cy - t / 2 + 2, t - 4, t - 4); g.restore();
      }
    }
  }
  function desenharLuzes() {
    var L = LUZES[cfg.robo]; if (!L || !ui.stPad) return;
    var cores = COR_SETA[cfg.robo], n = L.pontos.length, ini = Math.max(0, setas.length - n);
    ui.luzes = [];
    Array.prototype.slice.call(ui.stPad.querySelectorAll('.st-luz,.st-traco')).forEach(function (e) { e.parentNode.removeChild(e); });
    var pad = ui.stPad.firstChild ? ui.stPad.firstChild.nextSibling : null;
    L.pontos.forEach(function (pt, j) {
      var c = setas[ini + j], d = L.d * 100;
      var e = el('i', { 'class': 'st-luz' + (L.base ? ' base' : '') + (c ? ' acesa' : ''), style: 'left:' + (pt[0] * 100) + '%;top:' + (pt[1] * 100) + '%;width:' + d + '%;height:' + d + '%' + (c ? ';--luz:' + cores[c] : '') });
      ui.stPad.insertBefore(e, pad); ui.luzes.push(e);
    });
    ui.luzIni = ini;
    if (L.tracos) L.tracos.forEach(function (pt, j) {
      var e = el('i', { 'class': 'st-traco' + (repet > 1 && j < repet ? ' aceso' : ''), style: 'left:' + (pt[0] * 100) + '%;top:' + (pt[1] * 100) + '%;width:' + (L.tw * 100) + '%;height:' + (L.th * 100) + '%' });
      ui.stPad.insertBefore(e, pad);
    });
  }
  function ehSetas() { return !!CONTROLES[cfg.robo]; }
  function salvarSetas() { salvar('setas', setas); salvar('setasRep', repet); }
  function mostrarRepet() {
    var tem = !!CONTROLES[cfg.robo] && CONTROLES[cfg.robo].bts.some(function (b) { return b.c === 'T'; });
    if (ui.stRepet) { ui.stRepet.textContent = '🔁 ' + repet + '×'; ui.stRepet.style.display = tem ? '' : 'none'; }
    desenharLuzes();
    if (ui.stBadge) { ui.stBadge.textContent = repet + '×'; ui.stBadge.style.display = repet > 1 ? '' : 'none'; }
  }
  function setasRepetir() {
    if (exec.rodando) return;
    repet = repet % 4 + 1; salvarSetas(); mostrarRepet();
    aviso(repet > 1 ? '🔁 O programa vai se repetir ' + repet + ' vezes.' : 'O programa vai rodar uma vez só.', true);
  }
  function setasAdicionar(c) {
    if (exec.rodando) return;
    if (setas.length >= maxSetas()) { aviso('A bandeja está cheia (' + maxSetas() + ' comandos). Apague algum com o X.'); return; }
    aviso(''); setas.push(c); salvarSetas(); desenharSetas(true);
  }
  function setasApagar(tudo) {
    if (exec.rodando) return;
    if (tudo) { setas = []; repet = 1; } else setas.pop();
    salvarSetas(); desenharSetas(false); mostrarRepet();
  }
  function miniatura(def, tam) {
    var lado = def.i[2], bs = tam / lado;
    return 'background-size:' + bs.toFixed(1) + 'px ' + bs.toFixed(1) + 'px;background-position:' + (-(def.i[0] - lado / 2) * bs).toFixed(1) + 'px ' + (-(def.i[1] - lado / 2) * bs).toFixed(1) + 'px;';
  }
  function destacarSeta(i) {
    if (!ui.stLista) return;
    Array.prototype.forEach.call(ui.stLista.querySelectorAll('.st-chip'), function (e, k) {
      e.classList.toggle('rodando', k === i); e.classList.toggle('feito', i >= 0 && k < i);
      if (k === i && e.scrollIntoView) e.scrollIntoView({ block: 'nearest', inline: 'nearest' });
    });
    setaAtual = i;
    if (ui.luzes) ui.luzes.forEach(function (e, j) { e.classList.toggle('atual', i >= 0 && j + ui.luzIni === i); });
  }
  function desenharSetas(novo) {
    if (!ui.stLista) return;
    var def = CONTROLES[cfg.robo]; ui.stLista.textContent = '';
    if (!def) return;
    if (!setas.length) ui.stLista.appendChild(el('div', { 'class': 'st-vazio', text: 'Aperte as setas do controle para montar o programa. Os comandos ficam aqui, na ordem.' }));
    setas.forEach(function (c, k) {
      var b = def.bts.filter(function (x) { return x.c === c; })[0]; if (!b) return;
      ui.stLista.appendChild(el('div', { 'class': 'st-chip' + (novo && k === setas.length - 1 ? ' novo' : ''), style: miniatura(b, 60), title: NOME_SETA[c] }, [el('b', { text: String(k + 1) })]));
    });
    ui.stContagem.textContent = setas.length + ' / ' + maxSetas(); desenharLuzes();
    if (novo) ui.stLista.scrollTop = ui.stLista.scrollHeight;
  }
  function montarControle() {
    var def = CONTROLES[cfg.robo]; if (!ui.setas || !def) return;
    ui.setas.style.setProperty('--ctl', 'url(' + def.img + ')');
    ui.stPad.textContent = ''; ui.stPad.appendChild(el('img', { src: def.img, alt: 'Controle do robô' }));
    ui.stPlay = null; ui.stBadge = null;
    def.bts.forEach(function (b) {
      var bt = el('button', { type: 'button', 'class': 'st-hs', title: NOME_SETA[b.c], 'aria-label': NOME_SETA[b.c],
        style: 'left:' + (b.h[0] * 100) + '%;top:' + (b.h[1] * 100) + '%;width:' + (b.h[2] * 100) + '%;height:' + (b.h[3] * 100) + '%;border-radius:' + b.r });
      var segurou = false, timer = null;
      if (b.c === 'X') {
        bt.addEventListener('pointerdown', function () { segurou = false; clearTimeout(timer); timer = setTimeout(function () { segurou = true; setasApagar(true); nota(freqMidi(43), 0.2, 'square'); }, 650); });
        ['pointerup', 'pointerleave', 'pointercancel'].forEach(function (ev) { bt.addEventListener(ev, function () { clearTimeout(timer); }); });
      }
      bt.addEventListener('click', function () {
        audio(); nota(freqMidi(SOM_SETA[b.c] || 70), 0.07, 'triangle');
        if (b.c === 'P') { if (exec.rodando) pararPrograma(); else executar(); }
        else if (b.c === 'X') { if (segurou) segurou = false; else setasApagar(false); }
        else if (b.c === 'T') setasRepetir();
        else setasAdicionar(b.c);
      });
      if (b.c === 'P') ui.stPlay = bt;
      if (b.c === 'T') {
        ui.stBadge = el('span', { 'class': 'st-badge', style: 'display:none' }); bt.appendChild(ui.stBadge);
      }
      ui.stPad.appendChild(bt);
    });
    desenharSetas(false); mostrarRepet();
  }
  function criarSetas() {
    ui.stPad = el('div', { 'class': 'st-pad' });
    ui.stLista = el('div', { 'class': 'st-lista' });
    ui.stContagem = el('small', { text: '0 / ' + maxSetas() });
    ui.stRepet = el('small', { 'class': 'st-rep', title: 'Quantas vezes o programa todo se repete' });
    var limpar = el('button', { type: 'button', title: 'Apagar todos os comandos', text: '🗑 Limpar', onclick: function () { setasApagar(true); } });
    ui.setas = el('div', { id: 'setas' }, [
      el('div', { 'class': 'st-ctrl' }, [ui.stPad]),
      el('div', { 'class': 'st-prog' }, [
        el('div', { 'class': 'st-topo' }, [el('span', { text: '🧩 Meu programa' }), ui.stRepet, ui.stContagem, limpar]),
        ui.stLista,
        el('div', { 'class': 'st-dica', text: 'Aperte as setas na ordem que o robô deve andar. O ▶ do meio executa tudo. O X apaga o último comando; segure o X para apagar todos. No Tale, o botão do balão com seta repete o programa inteiro (1 a 4 vezes).' })])]);
    document.getElementById('editor').appendChild(ui.setas);
    montarControle();
  }
  // executa a bandeja, um comando de cada vez (cada seta anda 1 quadrante ou gira 90°)
  var MELODIA = [60, 64, 67, 72], DANCA = [72, 76, 79, 76, 72, 76, 79, 84];
  function setasPilhas(r) {
    var lista = setas.slice(); if (!lista.length) return [];
    var voltas = ehSetas() && CONTROLES[cfg.robo].bts.some(function (b) { return b.c === 'T'; }) ? repet : 1;
    return [{ id: 'setas', cond: null, fn: async function () {
      var v, i, c, k;
      for (v = 1; v <= voltas; v++) {
        if (voltas > 1) registrar('🔁 Volta ' + v + ' de ' + voltas);
        for (i = 0; i < lista.length; i++) {
          r.seta(i); c = lista[i];
          if (c === 'F') await r.mover('forward', PASSO, 'cm');
          else if (c === 'B') await r.mover('backward', PASSO, 'cm');
          else if (c === 'L') await r.girar('left', anguloSeta(), 'degrees');
          else if (c === 'R') await r.girar('right', anguloSeta(), 'degrees');
          else if (c === 'M') { for (k = 0; k < MELODIA.length; k++) await r.nota(MELODIA[k], 0.5); }
          else if (c === 'D') { DANCA.forEach(function (n, j) { nota(freqMidi(n), 0.16, 'triangle', j * 0.22); }); await r.girar('right', 360, 'degrees'); }
          else if (c === 'V') { r.falar('Olá!'); await r.esperar(1); }
          await r.esperar(0.15);
        }
      }
      r.seta(-1);
    } }];
  }

  /* ---------- Perfil por robô: o Nous usa os blocos e as cores do app do Nous ---------- */
  function ehNous() { return cfg.robo === 'nous'; }
  function caixaAtual() { return ehNous() ? window.RoboBlocos.caixaNous() : window.RoboBlocos.CAIXA; }
  function temaAtual() { return ehNous() ? window.RoboBlocos.TEMA_NOUS : window.RoboBlocos.TEMA; }
  var perfilAtual = null;
  var PROGRAMA_NOUS = { blocks: { languageVersion: 0, blocks: [{ type: 'rn_quando_iniciar', x: 40, y: 40,
    next: { block: { type: 'rn_mover', fields: { DIR: 'forward', UN: 'cm' }, inputs: { VALOR: { shadow: { type: 'math_number', fields: { NUM: 10 } } }, VEL: { shadow: { type: 'math_number', fields: { NUM: 100 } } } } } } }] } };
  // ao trocar de robô o programa recomeça do zero, com o programa inicial do robô novo
  var roboPrograma = null;
  function recomecarPrograma() {
    var B = window.Blockly;
    pararPrograma();
    B.Events.disable();
    try { ws.clear(); B.serialization.workspaces.load(ehNous() ? PROGRAMA_NOUS : PROGRAMA_INICIAL, ws); } finally { B.Events.enable(); }
    salvar('programa', B.serialization.workspaces.save(ws));
    roboPrograma = cfg.robo; salvar('programaRobo', cfg.robo);
    setas = []; repet = 1; salvarSetas(); desenharSetas(false); mostrarRepet();
  }
  function chavePerfil() { return ehNous() ? 'nous' : (ehSetas() ? 'setas-' + cfg.robo : 'padrao'); }
  function aplicarPerfil() {
    var nous = ehNous(), modoSetas = ehSetas();
    document.body.classList.toggle('perfil-nous', nous);
    document.body.classList.toggle('modo-setas', modoSetas);
    if (ui.canvas) ajustar();
    if (!ws || perfilAtual === chavePerfil()) return;
    perfilAtual = chavePerfil();
    if (ui.setas) montarControle();
    if (!modoSetas) window.setTimeout(function () { try { window.Blockly.svgResize(ws); } catch (e) { /* editor ainda escondido */ } }, 0);
    ws.setTheme(temaAtual()); ws.updateToolbox(caixaAtual());
  }
  /* ---------- Editor de blocos ---------- */
  var PROGRAMA_INICIAL = { blocks: { languageVersion: 0, blocks: [{ type: 'rb_quando_iniciar', x: 40, y: 40,
    next: { block: { type: 'rb_mover', fields: { DIR: 'forward', UN: 'cm' }, inputs: { VALOR: { shadow: { type: 'math_number', fields: { NUM: 10 } } } } } } }] } };
  function criarEditor() {
    var B = window.Blockly;
    ws = B.inject('blockly', {
      toolbox: caixaAtual(), theme: temaAtual(), renderer: 'zelos', sounds: false, trashcan: false,
      media: 'data:,', grid: { spacing: 28, length: 2, colour: '#d5dbe3', snap: false },
      zoom: { controls: false, wheel: true, startScale: (window.innerWidth < 760 || window.innerHeight < 520) ? 0.75 : 1, maxScale: 1.6, minScale: 0.4, scaleSpeed: 1.1 }, move: { scrollbars: true, drag: true, wheel: true }
    });
    if (window.MeusBlocos) window.MeusBlocos.instalar(ws);
    var salvo = carregar('programa', null), de = carregar('programaRobo', null);
    if (de && de !== cfg.robo) { salvo = null; setas = []; repet = 1; salvarSetas(); }   // o programa salvo era de outro robô
    roboPrograma = cfg.robo; salvar('programaRobo', cfg.robo);
    try { B.serialization.workspaces.load(salvo || (ehNous() ? PROGRAMA_NOUS : PROGRAMA_INICIAL), ws); } catch (e) { console.warn(e); B.serialization.workspaces.load(PROGRAMA_INICIAL, ws); }
    var espera = null;
    ws.addChangeListener(function (ev) {
      if (ev.isUiEvent) return;
      clearTimeout(espera); espera = setTimeout(function () { salvar('programa', B.serialization.workspaces.save(ws)); }, 400);
    });
  }
  function carregarRobo() {
    var r = robocfg(); cfg.robo = r.id; TAM_ROBO = r.tam; imgRobo.src = r.img;
    if (r.fases.indexOf(cfg.fase) < 0) { cfg.fase = 0; salvar('fase', 0); }
    if (ui.robos) ui.robos.forEach(function (b) { b.classList.toggle('ativo', b.dataset.robo === r.id); });
    aplicarPerfil();
    if (ws && roboPrograma !== r.id) { recomecarPrograma(); apagarDesenho(); }
    if (setas.length > maxSetas()) { setas = setas.slice(0, maxSetas()); salvarSetas(); }
    atualizarFases(); if (ui.stLista) desenharSetas(false); if (ui.canvas) reiniciar();
  }

  function pronto() {
    carregarRobo();
    document.getElementById('logo').src = A.logo;
    criarEditor(); perfilAtual = chavePerfil(); criarSetas(); criarPainel(); atualizarFases(); reiniciar();
    window.requestAnimationFrame(quadro);
  }
  window.RoboVirtual = { R: R, robo: robo, cfg: cfg, jogo: jogo, tela: tela, exec: exec, executar: executar, parar: pararPrograma, reiniciar: reiniciar, tracos: function () { return tracos; },
    conferir: conferir, verificar: verificar, escolherFase: escolherFase, escolherCaneta: escolherCaneta, apagar: apagarDesenho, moldeDe: moldeDe, FASES: FASES,
    trocarRobo: function (id) { cfg.robo = id; salvar('robo', id); carregarRobo(); }, ws: function () { return ws; }, setas: function () { return setas; } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', pronto); else pronto();
})();
