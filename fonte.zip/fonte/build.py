# Junta Blockly (npm i blockly), as imagens de img/ e os arquivos desta pasta em dist/index.html.
# Uso (na pasta onde está node_modules): python3 -I src/build.py   (src = esta pasta)
import base64, os
def r(p): return open(p, encoding='utf-8').read()
def uri(p, mime): return 'data:%s;base64,%s' % (mime, base64.b64encode(open(p, 'rb').read()).decode())
nm = 'node_modules/blockly/'
img = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'img') + '/'
def im(n, m): return uri(img + n, m)
arq = 'window.ROBO_ARQUIVOS=' + '{' + ','.join('%s:"%s"' % (k, v) for k, v in [
    ('robo', im('robo-vincibot.png', 'image/png')), ('roboMatata', im('robo-matata.png', 'image/png')), ('roboTale', im('robo-tale.png', 'image/png')),
    ('roboNous', im('robo-nous.png', 'image/png')), ('controleMatata', im('controle-matata.webp', 'image/webp')), ('controleTale', im('controle-tale.webp', 'image/webp')),
    ('pecasMatata', im('pecas-matata.webp', 'image/webp')), ('logo', im('zoom.png', 'image/png'))]) + '};'
t = r('src/index.template.html')
def js(s): return s.replace('</script', '<\\/script')
for k, v in [('/*BLOCKLY*/', r(nm + 'blockly_compressed.js')), ('/*BLOCKS*/', r(nm + 'blocks_compressed.js')), ('/*MSG*/', r(nm + 'msg/pt-br.js')), ('/*ARQUIVOS*/', arq),
             ('/*BLOCOS*/', r('src/blocos.js')), ('/*MEUS*/', r('src/meus.js')), ('/*APP*/', r('src/app.js'))]:
    assert t.count(k) == 1, k
    t = t.replace(k, js(v).replace('//# sourceMappingURL', '// map'))
os.makedirs('dist', exist_ok=True)
open('dist/index.html', 'w', encoding='utf-8').write(t)
print('dist/index.html', len(t))
