/*
 * Meus Blocos — criar o seu próprio bloco, no estilo do MatataCode:
 * "Criar um Bloco" abre uma janela com o nome, entradas (número ou texto, booleano) e rótulos;
 * o bloco "definir ..." recebe a pilha e o bloco novo aparece na paleta, pronto para usar.
 */
(function () {
  'use strict';
  var B = window.Blockly;
  var COR = '#FF6680', COR_ESC = '#E0455F';

  function uid() { return 'mb' + Date.now().toString(36) + Math.floor(Math.random() * 1679616).toString(36); }
  function copiar(p) { return JSON.parse(JSON.stringify(p)); }
  function proxId(partes) { var m = 0; partes.forEach(function (p) { if (p.id) m = Math.max(m, parseInt(p.id.slice(1), 10) || 0); }); return 'a' + (m + 1); }
  function ordem(partes) { return partes.filter(function (p) { return p.t !== 'rot'; }); }

  /* ---------- bloco de entrada de texto/número (padrão das entradas "número ou texto") ---------- */
  B.common.defineBlocksWithJsonArray([
    { type: 'mb_entrada', message0: '%1', args0: [{ type: 'field_input', name: 'TXT', text: '' }], output: null, style: 'math_blocks', outputShape: 2 }
  ]);

  /* ---------- parâmetro (a bolinha que se arrasta da definição para dentro da pilha) ---------- */
  function defParam(tipo, bool) {
    B.Blocks[tipo] = {
      init: function () {
        this.appendDummyInput().appendField(new B.FieldLabel('x'), 'NOME');
        this.setOutput(true, bool ? 'Boolean' : null); this.setStyle('meus_param'); this.setInputsInline(true);
        this.setTooltip('Valor que veio na chamada do bloco. Arraste para dentro da pilha.');
      },
      saveExtraState: function () { return { nome: this.getFieldValue('NOME') }; },
      loadExtraState: function (s) { this.setFieldValue((s && s.nome) || 'x', 'NOME'); }
    };
  }
  defParam('mb_param', false); defParam('mb_param_b', true);

  /* ---------- definição: "definir andar [dist] cm" ---------- */
  B.Blocks.mb_definir = {
    init: function () {
      this.uid_ = uid(); this.partes_ = [{ t: 'rot', v: 'bloco' }];
      this.setStyle('meus_hat'); this.setNextStatement(true); this.setInputsInline(true);
      this.setTooltip('Os blocos que ficarem embaixo daqui rodam quando o bloco novo for usado.');
      this.formar_();
    },
    saveExtraState: function () { return { uid: this.uid_, partes: this.partes_ }; },
    loadExtraState: function (s) { this.uid_ = s.uid; this.partes_ = s.partes; this.formar_(); },
    atualizar: function (partes) { this.partes_ = copiar(partes); this.formar_(); },
    formar_: function () {
      var i, self = this;
      this.inputList.slice().forEach(function (inp) { self.removeInput(inp.name); });
      var topo = this.appendDummyInput('TOPO').appendField('definir');
      this.partes_.forEach(function (p, k) {
        if (p.t === 'rot') { self.appendDummyInput('R' + k).appendField(new B.FieldLabel(p.v), 'L' + k); return; }
        var inp = self.appendValueInput('A_' + p.id).setCheck(p.t === 'b' ? 'Boolean' : null);
        inp.connection.setShadowState({ type: p.t === 'b' ? 'mb_param_b' : 'mb_param', data: self.uid_ + ':' + p.id, extraState: { nome: p.nome } });
      });
      void topo; void i;
      if (this.rendered) { this.initSvg(); this.render(); }
    },
    customContextMenu: function (op) {
      var self = this;
      op.push({ text: 'Editar', enabled: true, callback: function () { abrirJanela(self.workspace, self); } });
    }
  };

  /* ---------- chamada: o bloco que vai para o programa ---------- */
  B.Blocks.mb_chamar = {
    init: function () {
      this.uid_ = ''; this.partes_ = [{ t: 'rot', v: 'bloco' }];
      this.setStyle('meus_chamar'); this.setPreviousStatement(true); this.setNextStatement(true); this.setInputsInline(true);
      this.formar_();
    },
    saveExtraState: function () { return { uid: this.uid_, partes: this.partes_ }; },
    loadExtraState: function (s) { this.uid_ = s.uid; this.partes_ = s.partes; this.formar_(); },
    atualizar: function (partes) { this.partes_ = copiar(partes); this.formar_(); },
    formar_: function () {
      var self = this, guardados = {};
      this.inputList.slice().forEach(function (inp) {
        if (inp.name.indexOf('A_') === 0 && inp.connection) {
          var t = inp.connection.targetBlock();
          if (t && !t.isShadow()) { t.unplug(); guardados[inp.name] = t; }
        }
        self.removeInput(inp.name);
      });
      this.partes_.forEach(function (p, k) {
        if (p.t === 'rot') { self.appendDummyInput('R' + k).appendField(new B.FieldLabel(p.v), 'L' + k); return; }
        var inp = self.appendValueInput('A_' + p.id).setCheck(p.t === 'b' ? 'Boolean' : null);
        if (p.t !== 'b') inp.connection.setShadowState({ type: 'mb_entrada', fields: { TXT: p.t === 'n' ? '0' : '' } });
        var g = guardados['A_' + p.id];
        if (g && g.outputConnection) { try { inp.connection.connect(g.outputConnection); } catch (e) { /* tipo diferente: o bloco fica solto */ } }
      });
      if (this.rendered) { this.initSvg(); this.render(); }
    },
    customContextMenu: function (op) {
      var self = this;
      op.push({ text: 'Editar', enabled: true, callback: function () {
        var d = definicao(self.workspace, self.uid_); abrirJanela(self.workspace, d || self);
      } });
    }
  };

  function definicoes(ws) { return ws.getBlocksByType('mb_definir', false); }
  function definicao(ws, id) { return definicoes(ws).filter(function (d) { return d.uid_ === id; })[0] || null; }

  /* arrastar a bolinha da definição cria uma cópia (como no Scratch) */
  function copiarParam(ws, shadow, e) {
    var id = shadow.data, p = (shadow.getParent() && shadow.getParent().partes_ || []).filter(function (q) { return id.indexOf(':' + q.id) > 0; })[0];
    var novo = ws.newBlock(shadow.type); novo.data = id; novo.setFieldValue(shadow.getFieldValue('NOME'), 'NOME'); novo.initSvg(); novo.render();
    var off = ws.getOriginOffsetInPixels(), r = ws.getParentSvg().getBoundingClientRect();
    novo.moveBy((e.clientX - r.left - off.x) / ws.scale - 16, (e.clientY - r.top - off.y) / ws.scale - 10);
    if (B.Touch && B.Touch.shouldHandleEvent) B.Touch.shouldHandleEvent(e);          // o Blockly só encerra o arraste se viu o pointerdown
    var g = ws.getGesture(e); if (!g) return;
    g.handleBlockStart(e, novo); g.handleWsStart(e, ws); void p;
  }
  function ligarParam(ws, b) {
    if (!b || !b.isShadow || !b.isShadow() || (b.type !== 'mb_param' && b.type !== 'mb_param_b') || b.__copia) return;
    b.__copia = true;
    var raiz = b.getSvgRoot(); if (!raiz) return;
    raiz.addEventListener('pointerdown', function (e) { if (e.button !== 0 || ws.options.readOnly) return; e.stopPropagation(); e.preventDefault(); copiarParam(ws, b, e); }, true);
  }

  /* ---------- janela "Criar um Bloco" ---------- */
  var janela = null;
  function fechar() { if (janela && janela.parentNode) janela.parentNode.removeChild(janela); janela = null; }
  function abrirJanela(ws, editar) {
    fechar();
    var partes = editar ? copiar(editar.partes_) : [{ t: 'rot', v: 'bloco' }];
    var raiz = document.createElement('div'); raiz.className = 'mb-fundo';
    var cx = document.createElement('div'); cx.className = 'mb-caixa';
    var tit = document.createElement('div'); tit.className = 'mb-tit'; tit.textContent = editar ? 'Editar bloco' : 'Criar um Bloco';
    var prev = document.createElement('div'); prev.className = 'mb-prev';
    var barra = document.createElement('div'); barra.className = 'mb-barra';
    var erro = document.createElement('div'); erro.className = 'mb-erro';
    var fim = document.createElement('div'); fim.className = 'mb-fim';
    function botao(txt, fn, cls) { var b = document.createElement('button'); b.type = 'button'; b.textContent = txt; b.className = cls || ''; b.addEventListener('click', fn); return b; }
    function nomeLivre(base) { var n = 1, ok; do { ok = !partes.some(function (p) { return p.nome === base + n; }); if (!ok) n++; } while (!ok); return base + n; }
    function desenhar(foco) {
      prev.textContent = '';
      partes.forEach(function (p, k) {
        var w = document.createElement('span'); w.className = 'mb-' + (p.t === 'rot' ? 'rot' : p.t === 'b' ? 'bool' : 'ent');
        var inp = document.createElement('input'); inp.type = 'text'; inp.maxLength = 18; inp.value = p.t === 'rot' ? p.v : p.nome; inp.spellcheck = false;
        inp.size = Math.max(2, inp.value.length + 1); inp.setAttribute('aria-label', p.t === 'rot' ? 'rótulo' : 'entrada');
        inp.addEventListener('input', function () { if (p.t === 'rot') p.v = inp.value; else p.nome = inp.value; inp.size = Math.max(2, inp.value.length + 1); });
        inp.addEventListener('keydown', function (e) { e.stopPropagation(); if (e.key === 'Enter') ok.click(); if (e.key === 'Escape') fechar(); });
        w.appendChild(inp);
        if (partes.length > 1) { var x = document.createElement('b'); x.textContent = '×'; x.title = 'Tirar'; x.addEventListener('click', function () { partes.splice(k, 1); desenhar(); }); w.appendChild(x); }
        prev.appendChild(w); if (foco === k) window.setTimeout(function () { inp.focus(); inp.select(); }, 0);
      });
    }
    function achar(c) { var q = c.split(':'); return q; }
    void achar;
    var ok = botao('OK', function () {
      var rots = partes.filter(function (p) { return p.t === 'rot'; }).map(function (p) { return p.v.trim(); }), nomes = ordem(partes).map(function (p) { return p.nome.trim(); });
      if (!partes.some(function (p) { return p.t === 'rot' && p.v.trim(); }) ) { erro.textContent = 'Dê um nome ao bloco (um rótulo com texto).'; return; }
      if (rots.some(function (r) { return !r; })) { erro.textContent = 'Há um rótulo vazio. Escreva algo ou tire-o.'; return; }
      if (nomes.some(function (n) { return !n; })) { erro.textContent = 'Toda entrada precisa de um nome.'; return; }
      if (nomes.some(function (n, i) { return nomes.indexOf(n) !== i; })) { erro.textContent = 'Duas entradas com o mesmo nome.'; return; }
      partes.forEach(function (p) { if (p.t === 'rot') p.v = p.v.trim(); else p.nome = p.nome.trim(); });
      var nome = partes.map(function (p) { return p.t === 'rot' ? p.v : '%'; }).join(' ');
      var outra = definicoes(ws).filter(function (d) { return d !== editar && d.partes_.map(function (p) { return p.t === 'rot' ? p.v : '%' + p.t; }).join(' ') === partes.map(function (p) { return p.t === 'rot' ? p.v : '%' + p.t; }).join(' '); })[0];
      if (outra) { erro.textContent = 'Já existe um bloco com esse jeito. Mude o nome.'; return; }
      void nome;
      fechar(); aplicar(ws, editar, partes);
    }, 'mb-ok');
    barra.appendChild(botao('＋ Entrada: número ou texto', function () { partes.push({ t: 'n', id: proxId(partes), nome: nomeLivre('número') }); desenhar(partes.length - 1); }, 'mb-add'));
    barra.appendChild(botao('＋ Entrada: booleano', function () { partes.push({ t: 'b', id: proxId(partes), nome: nomeLivre('booleano') }); desenhar(partes.length - 1); }, 'mb-add'));
    barra.appendChild(botao('＋ Rótulo', function () { partes.push({ t: 'rot', v: 'texto' }); desenhar(partes.length - 1); }, 'mb-add'));
    fim.appendChild(botao('Cancelar', fechar, 'mb-cancela')); fim.appendChild(ok);
    cx.appendChild(tit);
    var dica = document.createElement('div'); dica.className = 'mb-dica'; dica.textContent = 'Escreva o nome do bloco e acrescente entradas para ele receber valores. O formato do bloco aparece aqui:';
    cx.appendChild(dica); cx.appendChild(prev); cx.appendChild(barra); cx.appendChild(erro); cx.appendChild(fim);
    raiz.appendChild(cx); document.body.appendChild(raiz); janela = raiz;
    raiz.addEventListener('keydown', function (e) { e.stopPropagation(); });
    raiz.addEventListener('mousedown', function (e) { if (e.target === raiz) fechar(); });
    desenhar(0);
  }

  function atualizarParams(ws, id, partes) {         // nomes novos nas bolinhas já usadas dentro do programa
    ws.getAllBlocks(false).forEach(function (b) {
      if ((b.type === 'mb_param' || b.type === 'mb_param_b') && b.data && b.data.indexOf(id + ':') === 0) {
        var p = partes.filter(function (q) { return q.id && b.data === id + ':' + q.id; })[0];
        if (p) b.setFieldValue(p.nome, 'NOME');
      }
    });
  }
  function aplicar(ws, editar, partes) {
    B.Events.setGroup(true);
    try {
      if (editar) {
        var id = editar.uid_; editar.atualizar(partes);
        ws.getBlocksByType('mb_chamar', false).forEach(function (c) { if (c.uid_ === id) c.atualizar(partes); });
        atualizarParams(ws, id, partes); redefinirParams(ws, editar);
      } else {
        var caixa = ws.getBlocksBoundingBox(), x = 40, y = (caixa.bottom > caixa.top ? caixa.bottom : 0) + 50;
        var d = B.serialization.blocks.append({ type: 'mb_definir', x: x, y: y, extraState: { uid: uid(), partes: partes } }, ws);
        d.select && d.select(); redefinirParams(ws, d);
      }
    } finally { B.Events.setGroup(false); }
    try { ws.refreshToolboxSelection(); } catch (e) { /* sem caixa */ }
    var t = ws.getToolbox && ws.getToolbox();
    if (t && t.getToolboxItems) {                                    // reabre a paleta para o bloco novo aparecer
      var it = t.getToolboxItems().filter(function (i) { return i.getName && i.getName() === 'Meus Blocos'; })[0];
      if (it) window.setTimeout(function () { try { t.clearSelection(); t.setSelectedItem(it); } catch (e) { /* sem caixa */ } }, 60);
    }
  }
  function redefinirParams(ws, d) { d.inputList.forEach(function (i) { if (i.connection && i.connection.targetBlock()) ligarParam(ws, i.connection.targetBlock()); }); }

  /* ---------- paleta "Meus Blocos" ---------- */
  function instalar(ws) {
    ws.registerButtonCallback('criarMB', function () { abrirJanela(ws, null); });
    ws.registerToolboxCategoryCallback('MEUS_BLOCOS', function () {
      var itens = [{ kind: 'button', text: 'Criar um Bloco', callbackKey: 'criarMB' }], vistos = {};
      definicoes(ws).sort(function (a, b) { return a.getRelativeToSurfaceXY().y - b.getRelativeToSurfaceXY().y; }).forEach(function (d) {
        if (vistos[d.uid_]) return; vistos[d.uid_] = 1;
        itens.push({ kind: 'block', type: 'mb_chamar', extraState: { uid: d.uid_, partes: copiar(d.partes_) } });
      });
      return itens;
    });
    function ligarTodos() { definicoes(ws).forEach(function (d) { redefinirParams(ws, d); }); }
    function assinatura() { return definicoes(ws).map(function (d) { return d.uid_ + JSON.stringify(d.partes_); }).join('|'); }
    var espera = null, ultima = assinatura();
    ws.addChangeListener(function (ev) {
      if (ev.isUiEvent) return;
      clearTimeout(espera);
      espera = setTimeout(function () {
        ligarTodos();
        var a = assinatura();
        if (a !== ultima) { ultima = a; try { ws.refreshToolboxSelection(); } catch (e) { /* sem caixa */ } }
      }, 80);
    });
    ligarTodos();
  }

  window.MeusBlocos = { instalar: instalar, abrir: function (ws) { abrirJanela(ws, null); }, definicoes: definicoes };
})();
